import cv2

img = cv2.imread('redacted.png')
h, w, _ = img.shape

rect_y1 = int(h * 0.75)  # Position of the desired box
line_thickness = 5

# Draw the lower line (top of box)
cv2.line(img, (0, rect_y1), (w, rect_y1), (255, 255, 255), thickness=line_thickness)

# Draw the upper line (box is only 2 * thickness tall)
rect_y2 = rect_y1 - line_thickness * 2
cv2.line(img, (0, rect_y2), (w, rect_y2), (255, 255, 255), thickness=line_thickness)

cv2.imwrite('redacted2.png', img)