from computers import Computer, LocalPlaywrightComputer
from utils import create_response, show_image
import json


class Agent:
    def __init__(
        self,
        model="computer-use-preview-2025-02-04",
        computer: Computer = None,
        tools: list[dict] = [],
    ):
        self.model = model
        self.computer = computer
        self.tools = tools
        self.print_steps = True
        self.debug = False
        self.show_images = False

        if computer:
            self.tools += [
                {
                    "type": "computer-preview",
                    "display_width": computer.dimensions[0],
                    "display_height": computer.dimensions[1],
                    "environment": computer.environment,
                },
            ]

    def debug_print(self, *args):
        if self.debug:
            print(*args)
    

    def write_log(message):
        LOG_FILE = "debug_log.txt"
        """Helper function to append logs to a file."""
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(message + "\n")
    # write_log("🚀 Script started...")

    async def handle_item(self, item):
        # write_log(f"🔍 DEBUG: Received item of type {item['type']} → {json.dumps(item, indent=2)}")
        """Handle each item; may cause a computer action + screenshot."""
        if item["type"] == "message":
            if self.print_steps:
                print(item["content"][0]["text"])



        if item["type"] == "function_call":
            name, args = item["name"], json.loads(item["arguments"])
            if self.print_steps:
                print(f"{name}({args})")

            if hasattr(self.computer, name):
                method = getattr(self.computer, name)
                await method(**args)
                return [
                    {
                        "type": "function_call_output",
                        "call_id": item["call_id"],
                        "output": f"success",
                    }
                ]
            # else:
            #     return [
            #         {
            #             "type": "function_call_output",
            #             "call_id": item["call_id"],
            #             "output": f"Method {name} not found on computer",
            #         }
            #     ]

            # return [
            #     {
            #         "type": "function_call_output",
            #         "call_id": item["call_id"],
            #         "output": "[some hard coded value]",
            #     }
            # ]

        if item["type"] == "computer_call":
            action = item["action"]
            action_type = action["type"]
            action_args = {k: v for k, v in action.items() if k != "type"}
            # write_log(f"🚀 Attempting {action_type} with args: {action_args}")
            if self.print_steps:
                print(f"{action_type}({action_args})")

            await getattr(self.computer, action_type)(**action_args)

            if action_type == "click" and action_args.get("button") == "wheel":
                print("🖱️ Handling wheel click...")

            screenshot_base64 = await self.computer.screenshot()
            if self.show_images:
                show_image(screenshot_base64)
            return [
                {
                    "type": "computer_call_output",
                    "call_id": item["call_id"],
                    "output": {
                        "type": "input_image",
                        "image_url": f"data:image/png;base64,{screenshot_base64}",
                    },
                }
            ]
        return []


    async def run_full_turn(self, input_items, print_steps=True, debug=False, show_images=False):
        self.print_steps = print_steps
        self.debug = debug
        self.show_images = show_images
        new_items = []
        while new_items[-1].get("role") != "assistant" if new_items else True:
            self.debug_print(input_items + new_items)
    
            response = create_response(
                model=self.model,
                input=input_items + new_items,
                tools=self.tools,
                # truncation="disabled",
            )
            self.debug_print(response)
    
            if "output" not in response and self.debug:
                print(response)
                raise ValueError("No output from model")
    
            new_items += response["output"]
            for item in response["output"]:
                new_items += await self.handle_item(item)
    
        return new_items

