# computers/base_playwright.py
import time
import base64
from typing import List, Dict, Literal
from playwright.async_api import async_playwright, Browser, Page
import asyncio 

CUA_KEY_TO_PLAYWRIGHT_KEY = {
    "/": "Divide",
    "\\": "Backslash",
    "alt": "Alt",
    "arrowdown": "ArrowDown",
    "arrowleft": "ArrowLeft",
    "arrowright": "ArrowRight",
    "arrowup": "ArrowUp",
    "backspace": "Backspace",
    "capslock": "CapsLock",
    "cmd": "Meta",
    "ctrl": "Control",
    "delete": "Delete",
    "end": "End",
    "enter": "Enter",
    "esc": "Escape",
    "home": "Home",
    "insert": "Insert",
    "option": "Alt",
    "pagedown": "PageDown",
    "pageup": "PageUp",
    "shift": "Shift",
    "space": " ",
    "super": "Meta",
    "tab": "Tab",
    "win": "Meta",
}


class BasePlaywrightComputer:
    environment: Literal["browser"] = "browser"
    dimensions = (1280, 800)

    async def get_current_url(self):
        return await self.page.evaluate("window.location.href")


    async def __aenter__(self):
        self._playwright = await async_playwright().start()
        self._browser, self._page = await self._get_browser_and_page()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self._browser:
            await self._browser.close()  
        if self._playwright:
            await self._playwright.stop()

    async def _get_browser_and_page(self) -> tuple[Browser, Page]:
        raise NotImplementeedError

    async def screenshot(self) -> str:
        png_bytes = await self._page.screenshot(full_page=False)
        return base64.b64encode(png_bytes).decode("utf-8")

    async def click(self, x: int, y: int, button: str = "left") -> None:
        if button == "wheel":
            await self._page.mouse.click(x, y, button="middle")  
        else:
            await self._page.mouse.click(x, y, button=button)

    async def double_click(self, x: int, y: int) -> None:
        await self._page.mouse.dblclick(x, y)

    async def scroll(self, x: int, y: int, scroll_x: int, scroll_y: int) -> None:
        await self._page.mouse.move(x, y)
        try:
            await self._page.mouse.wheel(delta_x=scroll_x, delta_y=scroll_y)
            await asyncio.sleep(0.5)
        except Exception as e:
            print(f"⚠️ Mouse wheel scrolling failed: {e}. Using JavaScript fallback.")
            await self._page.evaluate(f"window.scrollBy({scroll_x}, {scroll_y})")
            await asyncio.sleep(0.5)

    async def type(self, text: str) -> None:
        await self._page.keyboard.type(text)

    async def wait(self, ms: int = 1000) -> None:
        await asyncio.sleep(ms / 1000)

    async def move(self, x: int, y: int) -> None:
        await self._page.mouse.move(x, y)

    # async def keypress(self, keys: List[str]) -> None:
    #     for key in keys:
    #         mapped_key = CUA_KEY_TO_PLAYWRIGHT_KEY.get(key.lower(), key)
    #         await self._page.keyboard.press(mapped_key)
##########################
    # async def keypress(self, keys: List[str]) -> None:
    #     mapped_keys = [CUA_KEY_TO_PLAYWRIGHT_KEY.get(key.lower(), key) for key in keys]
    #     # print(f"Processed keys: {mapped_keys}")  
    
    #     modifier_keys = {"Control", "Alt", "Shift", "Meta"}
    #     keys_to_hold = [key for key in mapped_keys if key in modifier_keys]
    #     normal_keys = [key for key in mapped_keys if key not in modifier_keys]
    
    #     try:
    #         for key in keys_to_hold:
    #             # print(f"Holding {key}")
    #             await self._page.keyboard.down(key)
    
    #         for key in normal_keys:
    #             # print(f"Pressing {key}")
    #             await self._page.keyboard.press(key)  
    
    #     finally:
    #         for key in keys_to_hold:
    #             # print(f"Releasing {key}")
    #             await self._page.keyboard.up(key)
#############################
    async def keypress(self, keys: List[str]) -> None:
        mapped_keys = [CUA_KEY_TO_PLAYWRIGHT_KEY.get(key.lower(), key) for key in keys]
        
        # If the model tries to press Control or Alt, navigate to the home page.
        if any(key in {"Control", "Alt"} for key in mapped_keys):
            # Log that we're ignoring key events and navigating home.
            print("Detected Control/Alt in key sequence. Navigating to home page instead.")
            # await self.goto("http://duckduckgo.com")
            return
        
        modifier_keys = {"Control", "Alt", "Shift", "Meta"}
        keys_to_hold = [key for key in mapped_keys if key in modifier_keys]
        normal_keys = [key for key in mapped_keys if key not in modifier_keys]
    
        try:
            for key in keys_to_hold:
                await self._page.keyboard.down(key)
    
            for key in normal_keys:
                await self._page.keyboard.press(key)
    
        finally:
            for key in keys_to_hold:
                await self._page.keyboard.up(key)




    async def drag(self, path: List[List[int]]) -> None:
        if not path:
            return
        await self._page.mouse.move(*path[0])
        await self._page.mouse.down()
        for px, py in path[1:]:
            await self._page.mouse.move(px, py)
        await self._page.mouse.up()

    async def goto(self, url: str) -> None:
        await self._page.goto(url)

    async def back(self) -> None:
        await self._page.go_back()
